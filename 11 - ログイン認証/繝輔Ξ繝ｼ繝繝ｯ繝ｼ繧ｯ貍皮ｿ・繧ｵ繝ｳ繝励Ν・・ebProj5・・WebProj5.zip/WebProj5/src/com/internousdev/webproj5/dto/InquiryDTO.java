package com.internousdev.webproj5.dto;

public class InquiryDTO {

	private String name;
	private String qtype;
	private String body;

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getQtype() {
		return qtype;
	}
	public void setQtype(String qtype) {
		this.qtype = qtype;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}


}
